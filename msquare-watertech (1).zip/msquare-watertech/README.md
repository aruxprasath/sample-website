# M Square Watertech Service LLP – Website
React + Vite + plain CSS. Website by FUTECX.

## Run locally
```
npm install
npm run dev        # http://localhost:5173
npm run build      # outputs /dist
npm run preview    # test the production build
```
Needs Node.js 18+.

## Folder structure
```
index.html            SEO meta tags, Open Graph, LocalBusiness JSON-LD
public/               favicon, robots.txt, sitemap.xml, logo (placeholder)
src/data.js           ALL business details, services, steps, FAQ  <- edit here
src/styles.css        all styling (colour tokens at the top)
src/components/       Header, Hero, About, Services, Process, FAQ, Contact, Footer
```

## Logo
The client logo is `public/logo.png` (referenced in `src/data.js`). To change it, replace the file; adjust width/height in Header.jsx and Footer.jsx if the shape differs.

## Deploy (free options)
**Netlify:** push to GitHub → "Add new site" → import repo → build command `npm run build`, publish directory `dist`.
**Vercel:** import repo → framework "Vite" (auto-detected) → Deploy.
**Cloudflare Pages:** build command `npm run build`, output directory `dist`.
(Or drag the `dist` folder onto netlify.com/drop after `npm run build`.)

## Connect a custom domain
1. In the host dashboard (Netlify/Vercel/Cloudflare) open **Domains** → **Add custom domain**.
2. At the domain registrar add the DNS records the host shows (usually an A record for the root domain and a CNAME for `www`).
3. Wait for DNS to update (minutes to 48 hours); HTTPS is issued automatically.
4. Replace `https://www.example.com` with the real domain in `index.html` (canonical + og:url), `public/sitemap.xml` and `public/robots.txt`, then redeploy.

## Client confirmation checklist
- [x] Official logo file (PNG/SVG, transparent background) – done (public/logo.png); a transparent-background version would look cleaner on the dark footer
- [ ] Exact full form of "IRF" (shown only as "IRF Service" for now)
- [ ] Final domain name (canonical, sitemap, robots.txt, Open Graph)
- [ ] Exact business location / Google Maps listing (no map added yet)
- [ ] Business hours, email address (none published)
- [ ] Review of the service descriptions and FAQ answers for technical accuracy
- [ ] Whether the client offers installation, AMC or other services (not mentioned on the site)
- [ ] Real photos of work/team, if the client wants them added
- [ ] Any certifications, years of experience, service areas, pricing or warranties the client wants stated (none claimed now)
- [ ] Open Graph share image (1200x630)
- [ ] Confirm the WhatsApp number 9962650428 is active and is the preferred enquiry number
