// ===== EDIT BUSINESS DETAILS HERE =====
export const COMPANY = {
  name: 'M Square Watertech Service LLP',
  phoneDisplay: '+91 9962650428',
  phoneTel: '+919962650428',
  whatsapp: 'https://wa.me/919962650428',
  address: 'Kolathur, Chennai, Tamil Nadu – 600099',
  // Client logo (public/logo.png, 260x239)
  logo: '/logo.png',
}

export const waLink = (text) => `${COMPANY.whatsapp}?text=${encodeURIComponent(text)}`
export const serviceMessage = (s) =>
  `Hello ${COMPANY.name}, I would like to enquire about ${s}. Please share the details.`

export const SERVICES = [
  { id: 'ro', icon: 'Droplets', name: 'RO Service', text: 'Servicing and support for reverse osmosis (RO) drinking water purifiers.' },
  { id: 'softener', icon: 'Waves', name: 'Water Softener Service', text: 'Servicing and support for water softener systems used to treat hard water.' },
  { id: 'filter', icon: 'Filter', name: 'Water Filter Service', text: 'Servicing and maintenance support for water filtration units.' },
  { id: 'irf', icon: 'Layers', name: 'IRF Service', text: 'Servicing support for IRF water treatment units. Contact us to discuss your setup.' },
  { id: 'uf', icon: 'ListFilter', name: 'UF Service', text: 'Servicing and support for ultrafiltration (UF) water purification systems.' },
  { id: 'uv', icon: 'Lightbulb', name: 'UV Service', text: 'Servicing and support for ultraviolet (UV) water purification systems.' },
  { id: 'ozone', icon: 'Wind', name: 'Ozone Service', text: 'Servicing and support for ozone-based water treatment systems.' },
]

export const STEPS = [
  { t: 'Contact Us', d: 'Call or message us on WhatsApp.' },
  { t: 'Share Your Requirement', d: 'Tell us which system you have and what you need.' },
  { t: 'Discuss Service Scheduling', d: 'We talk through a suitable time for the service.' },
  { t: 'Service Support', d: 'Our team provides the service you requested.' },
]

export const FAQ = [
  { q: 'What is RO service?', a: 'RO service generally means checking and maintaining a reverse osmosis water purifier, which can include replacing worn parts such as filters or membranes where needed. Contact us to discuss your purifier.' },
  { q: 'Why does a water filter need maintenance?', a: 'Filters collect particles and impurities over time, so they usually need periodic cleaning or replacement. How often depends on your water quality and the type of filter.' },
  { q: 'What does a water softener do?', a: 'A water softener is used to treat hard water by reducing the minerals that cause hardness. Softeners generally need regular servicing to keep working properly.' },
  { q: 'What are UF and UV systems?', a: 'UF (ultrafiltration) uses a membrane to filter water. UV uses ultraviolet light as part of purification. Many purifiers combine different stages, and each stage may need its own servicing.' },
  { q: 'What is ozone water treatment?', a: 'Ozone treatment uses ozone as part of a water treatment process. Ask us if you want to discuss servicing for an ozone-based system.' },
  { q: 'How do I enquire about a service?', a: 'Call +91 9962650428, tap the WhatsApp button, or fill in the contact form. The form opens WhatsApp with your details ready to send.' },
]
