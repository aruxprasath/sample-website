import { useState } from 'react'
import { Menu, X, Phone } from 'lucide-react'
import { COMPANY } from '../data.js'

const LINKS = [['Home', '#home'], ['About', '#about'], ['Services', '#services'], ['How it works', '#process'], ['FAQ', '#faq'], ['Contact', '#contact']]

export default function Header() {
  const [open, setOpen] = useState(false)
  return (
    <header className="header">
      <a className="skip" href="#main">Skip to content</a>
      <div className="wrap header-in">
        <a href="#home" className="brand" aria-label={`${COMPANY.name} home`}>
          <img src={COMPANY.logo} alt={`${COMPANY.name} logo`} width="59" height="54" />
        </a>
        <nav id="nav" className={`nav ${open ? 'open' : ''}`} aria-label="Main">
          {LINKS.map(([l, h]) => <a key={h} href={h} onClick={() => setOpen(false)}>{l}</a>)}
        </nav>
        <a className="btn btn-sm btn-ghost hide-sm" href={`tel:${COMPANY.phoneTel}`}><Phone size={16} aria-hidden="true" /> {COMPANY.phoneDisplay}</a>
        <button className="burger" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} aria-controls="nav" onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </button>
      </div>
    </header>
  )
}
