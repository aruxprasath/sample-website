import { Phone, MessageCircle } from 'lucide-react'
import { COMPANY, SERVICES, waLink } from '../data.js'

export default function Hero() {
  return (
    <section id="home" className="hero">
      <div className="wrap hero-in">
        <div>
          <p className="kicker">{COMPANY.name}</p>
          <h1>Reliable Water Treatment &amp; Purification Solutions</h1>
          <p className="lead">{COMPANY.name} provides water purification, filtration and treatment services from Kolathur, Chennai. Tell us about your system and we will help with the service you need.</p>
          <div className="cta-row">
            <a className="btn btn-primary" href="#contact">Enquire Now</a>
            <a className="btn btn-ghost" href={`tel:${COMPANY.phoneTel}`}><Phone size={18} aria-hidden="true" /> Call Now</a>
            <a className="btn btn-wa" href={waLink(`Hello ${COMPANY.name}, I would like to make an enquiry.`)} target="_blank" rel="noopener noreferrer"><MessageCircle size={18} aria-hidden="true" /> WhatsApp</a>
          </div>
          <ul className="chips" aria-label="Services offered">
            {SERVICES.map((s) => <li key={s.id}><a href={`#svc-${s.id}`}>{s.name}</a></li>)}
          </ul>
        </div>
        <div className="vessel" role="img" aria-label="Illustration of a glass of clean water with a water drop">
          <svg viewBox="0 0 320 380" aria-hidden="true">
            <defs>
              <clipPath id="glass"><path d="M60 40h200l-24 300a24 24 0 01-24 22H108a24 24 0 01-24-22z" /></clipPath>
              <linearGradient id="w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#22B8D6" /><stop offset="1" stopColor="#0F5FA8" /></linearGradient>
            </defs>
            <g clipPath="url(#glass)">
              <rect width="320" height="380" fill="#EAF7FB" />
              <g className="tide"><path d="M-320 130q40-26 80 0t80 0t80 0t80 0t80 0t80 0t80 0v260h-560z" fill="url(#w)" /></g>
              <g className="tide slow"><path d="M-320 150q40-22 80 0t80 0t80 0t80 0t80 0t80 0t80 0v240h-560z" fill="#3F9B4A" opacity=".28" /></g>
              <circle className="bub" cx="130" cy="300" r="7" fill="#fff" opacity=".6" />
              <circle className="bub b2" cx="190" cy="320" r="5" fill="#fff" opacity=".6" />
              <circle className="bub b3" cx="160" cy="330" r="9" fill="#fff" opacity=".5" />
            </g>
            <path d="M60 40h200l-24 300a24 24 0 01-24 22H108a24 24 0 01-24-22z" fill="none" stroke="#0A2540" strokeWidth="5" strokeLinejoin="round" />
            <path className="drop" d="M160 -10c-14 20-24 30-24 44a24 24 0 0048 0c0-14-10-24-24-44z" fill="#22B8D6" />
          </svg>
        </div>
      </div>
    </section>
  )
}
