import { STEPS } from '../data.js'
export default function Process() {
  return (
    <section id="process" className="section">
      <div className="wrap">
        <h2 className="reveal">How It Works</h2>
        <ol className="steps">
          {STEPS.map((s, i) => (
            <li key={s.t} className="reveal">
              <span className="num" aria-hidden="true">{i + 1}</span>
              <h3>{s.t}</h3>
              <p>{s.d}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
