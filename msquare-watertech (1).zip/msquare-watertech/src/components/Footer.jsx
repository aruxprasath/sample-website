import { COMPANY, SERVICES } from '../data.js'
export default function Footer() {
  return (
    <footer className="footer">
      <div className="wrap foot-grid">
        <div>
          <img src={COMPANY.logo} alt={`${COMPANY.name} logo`} width="59" height="54" className="flogo" />
          <p><strong>{COMPANY.name}</strong></p>
          <p>{COMPANY.address}</p>
          <p><a href={`tel:${COMPANY.phoneTel}`}>{COMPANY.phoneDisplay}</a></p>
        </div>
        <nav aria-label="Footer quick links">
          <h2>Quick links</h2>
          <a href="#home">Home</a><a href="#about">About</a><a href="#process">How it works</a><a href="#faq">FAQ</a><a href="#contact">Contact</a>
        </nav>
        <nav aria-label="Footer services">
          <h2>Services</h2>
          {SERVICES.map((s) => <a key={s.id} href={`#svc-${s.id}`}>{s.name}</a>)}
        </nav>
      </div>
      <div className="wrap foot-base">
        <span>© {new Date().getFullYear()} {COMPANY.name}. All rights reserved.</span>
        <span className="credit">Website by FUTECX</span>
      </div>
    </footer>
  )
}
