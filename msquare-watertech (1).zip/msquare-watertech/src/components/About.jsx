import { COMPANY } from '../data.js'
export default function About() {
  return (
    <section id="about" className="section">
      <div className="wrap about reveal">
        <h2>About Us</h2>
        <div>
          <p>{COMPANY.name} is a water purification and water treatment service business based in Kolathur, Chennai.</p>
          <p>We focus on servicing water treatment systems, including RO, water softener, water filter, IRF, UF, UV and ozone systems. If you are unsure which service your system needs, contact us and describe what you have.</p>
        </div>
      </div>
    </section>
  )
}
