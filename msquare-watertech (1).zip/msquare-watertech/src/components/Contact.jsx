import { useState } from 'react'
import { Phone, MessageCircle, MapPin } from 'lucide-react'
import { COMPANY, SERVICES, waLink } from '../data.js'

const empty = { name: '', phone: '', service: '', message: '' }

export default function Contact() {
  const [v, setV] = useState(empty)
  const [err, setErr] = useState({})
  const set = (k) => (e) => setV({ ...v, [k]: e.target.value })

  const submit = (e) => {
    e.preventDefault()
    const x = {}
    if (v.name.trim().length < 2) x.name = 'Enter your name.'
    if (!/^(\+?91[\s-]?)?[6-9]\d{9}$/.test(v.phone.replace(/[\s-]/g, ''))) x.phone = 'Enter a valid 10-digit mobile number.'
    if (!v.service) x.service = 'Select the service you need.'
    setErr(x)
    if (Object.keys(x).length) return
    const text = `Hello ${COMPANY.name},\nName: ${v.name.trim()}\nPhone: ${v.phone.trim()}\nService: ${v.service}${v.message.trim() ? `\nMessage: ${v.message.trim()}` : ''}`
    window.open(waLink(text), '_blank', 'noopener,noreferrer')
  }

  const field = (k, label, el) => (
    <div className="field">
      <label htmlFor={k}>{label}</label>
      {el}
      {err[k] && <p className="err" id={`${k}-e`} role="alert">{err[k]}</p>}
    </div>
  )
  const a = (k) => ({ id: k, value: v[k], onChange: set(k), 'aria-invalid': !!err[k], 'aria-describedby': err[k] ? `${k}-e` : undefined })

  return (
    <section id="contact" className="section">
      <div className="wrap contact">
        <div className="reveal">
          <h2>Contact Us</h2>
          <address>
            <strong>{COMPANY.name}</strong>
            <span><MapPin size={18} aria-hidden="true" /> {COMPANY.address}</span>
            <span><Phone size={18} aria-hidden="true" /> <a href={`tel:${COMPANY.phoneTel}`}>{COMPANY.phoneDisplay}</a></span>
          </address>
          <div className="cta-row">
            <a className="btn btn-primary" href={`tel:${COMPANY.phoneTel}`}><Phone size={18} aria-hidden="true" /> Call Now</a>
            <a className="btn btn-wa" href={waLink(`Hello ${COMPANY.name}, I would like to make an enquiry.`)} target="_blank" rel="noopener noreferrer"><MessageCircle size={18} aria-hidden="true" /> WhatsApp Enquiry</a>
          </div>
        </div>
        <form className="form reveal" onSubmit={submit} noValidate>
          <h3>Send an enquiry</h3>
          <p className="note">This form does not store your details. Pressing the button opens WhatsApp with your message ready to send.</p>
          {field('name', 'Name *', <input {...a('name')} autoComplete="name" required />)}
          {field('phone', 'Phone number *', <input {...a('phone')} type="tel" inputMode="tel" autoComplete="tel" required />)}
          {field('service', 'Service required *', (
            <select {...a('service')} required>
              <option value="">Select a service</option>
              {SERVICES.map((s) => <option key={s.id} value={s.name}>{s.name}</option>)}
              <option value="Other / Not sure">Other / Not sure</option>
            </select>
          ))}
          {field('message', 'Message (optional)', <textarea {...a('message')} rows="3" />)}
          <button className="btn btn-wa" type="submit"><MessageCircle size={18} aria-hidden="true" /> Send on WhatsApp</button>
        </form>
      </div>
    </section>
  )
}
