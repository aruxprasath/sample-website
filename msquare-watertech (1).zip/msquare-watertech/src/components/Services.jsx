import { Droplets, Waves, Filter, Layers, ListFilter, Lightbulb, Wind, MessageCircle } from 'lucide-react'
import { SERVICES, waLink, serviceMessage } from '../data.js'

const ICONS = { Droplets, Waves, Filter, Layers, ListFilter, Lightbulb, Wind }

export default function Services() {
  return (
    <section id="services" className="section tint">
      <div className="wrap">
        <h2 className="reveal">Our Services</h2>
        <p className="sub reveal">Water treatment services in Chennai, including RO service in Kolathur and nearby areas.</p>
        <div className="grid">
          {SERVICES.map((s) => {
            const Icon = ICONS[s.icon]
            return (
              <article key={s.id} id={`svc-${s.id}`} className="card reveal">
                <span className="ico"><Icon size={26} aria-hidden="true" /></span>
                <h3>{s.name}</h3>
                <p>{s.text}</p>
                <a className="btn btn-sm btn-primary" href={waLink(serviceMessage(s.name))} target="_blank" rel="noopener noreferrer">
                  <MessageCircle size={16} aria-hidden="true" /> Enquire Now<span className="sr"> about {s.name}</span>
                </a>
              </article>
            )
          })}
        </div>
      </div>
    </section>
  )
}
