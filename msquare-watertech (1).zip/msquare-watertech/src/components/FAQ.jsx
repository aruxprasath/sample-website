import { useState } from 'react'
import { ChevronDown } from 'lucide-react'
import { FAQ as ITEMS } from '../data.js'

export default function FAQ() {
  const [open, setOpen] = useState(0)
  return (
    <section id="faq" className="section tint">
      <div className="wrap narrow">
        <h2 className="reveal">Frequently Asked Questions</h2>
        <div className="faq">
          {ITEMS.map((f, i) => (
            <div key={f.q} className={`qa ${open === i ? 'open' : ''}`}>
              <h3>
                <button aria-expanded={open === i} aria-controls={`a${i}`} id={`q${i}`} onClick={() => setOpen(open === i ? -1 : i)}>
                  {f.q}<ChevronDown aria-hidden="true" />
                </button>
              </h3>
              <div id={`a${i}`} role="region" aria-labelledby={`q${i}`} hidden={open !== i}><p>{f.a}</p></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
